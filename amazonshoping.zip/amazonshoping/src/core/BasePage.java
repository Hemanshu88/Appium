package core;

public interface BasePage {
	
	public abstract void waitForPageToLoad();
	
}
